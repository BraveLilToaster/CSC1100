#include <iostream>
using namespace std;

int main() {

	cout << "*****************************\n" << "* Programming Assignment 1  *\n" << "*   Computer Progamming 1   *\n" << "*   Author: Blake Levine    *\n" << "* Due Date: Thur, Sept. 11  *\n" << "*****************************\n"; 

		return 0;
}
